# KubeView

A lightweight web dashboard for monitoring a Kubernetes cluster. KubeView talks to your cluster through the standard kubeconfig and surfaces pods, deployments, services, nodes, namespaces, events, and pod logs in a clean, auto-refreshing UI — a browser-friendly companion to `kubectl get`.

![Dashboard](screenshots/01-dashboard.png)

## Features

- Cluster overview with live pod, deployment, and node health counts
- Namespace, pod, deployment, service, and node browsers with search and namespace filters
- Pod detail view with container info, conditions, volumes, and live log tail
- Auto-refresh every 5 seconds across every page
- **Cluster flight recorder** — records resource state changes and events into an embedded store (72h ring buffer by default); a timeline scrubber in the top bar re-renders every page as of any past moment, and the Timeline page diffs two moments (pod restarts, image changes, replica scaling, condition transitions) alongside the events that fired in between
- Read-only by design — never mutates cluster state

## Architecture

KubeView is a two-part application:

- **`kubeview-backend/`** — Go API on port `5501`. Connects to your cluster using `k8s.io/client-go` (loads kubeconfig from the default location). Exposes a small REST API and reshapes raw Kubernetes objects into a frontend-friendly JSON shape.
- **`kubeview-frontend/`** — Next.js 16 + React 19 + Tailwind v4 app on port `5500`. Polls the backend every 5 seconds and renders the data.

```
Browser  ──▶  Frontend (Next.js, :5500)  ──▶  Backend (Go, :5501)  ──▶  Kubernetes API
```

## Prerequisites

- **Go 1.26+** (for the backend)
- **Node.js 18+** (for the frontend)
- **A running Kubernetes cluster** reachable from your kubeconfig — Docker Desktop's built-in Kubernetes, [kind](https://kind.sigs.k8s.io/), [minikube](https://minikube.sigs.k8s.io/), or any remote cluster all work.
- **kubectl** configured. Verify with:
  ```bash
  kubectl get nodes
  ```
  If that command succeeds, KubeView will be able to connect.

## Getting started

Clone the repo and start the two services in separate terminals.

**Terminal 1 — backend:**
```bash
cd kubeview-backend
go run .
```
The API is now running at http://localhost:5501. You can sanity-check it with `curl http://localhost:5501/api/health`.

**Terminal 2 — frontend:**
```bash
cd kubeview-frontend
npm install
npm run dev
```
The dashboard is now running at http://localhost:5500. Open it in your browser.

## Configuration

Both services default to localhost ports but can be configured for non-local deployments via environment variables:

| Variable | Service | Default | Purpose |
|----------|---------|---------|---------|
| `PORT` | backend | `5501` | Port the API listens on. Note: `next start` (frontend production mode) also reads `PORT`, so give each service its own value when they share an environment. |
| `CORS_ORIGIN` | backend | `http://localhost:5500` | Comma-separated list of allowed browser origins, e.g. `https://kubeview.example.com,http://localhost:5500`. Origins must match the browser's `Origin` header exactly (scheme + host + port, no trailing slash); requests from unlisted origins get no CORS headers. |
| `KUBECONFIG` | backend | `~/.kube/config` | Kubeconfig path(s) used to reach the cluster; a colon-separated list is merged like `kubectl`. When unset and `~/.kube/config` is absent, the backend uses the in-cluster service account. |
| `HISTORY_RETENTION_HOURS` | backend | `72` | How far back the cluster flight recorder keeps state for time travel. `0` (or negative) disables history recording entirely. |
| `HISTORY_DIR` | backend | user cache dir | Directory holding the flight recorder's embedded store (`history.db`). Defaults to `~/.cache/kubeview` (falling back to the system temp dir); point it at a persistent volume in containers. |
| `NEXT_PUBLIC_API_BASE` | frontend | `http://localhost:5501/api` | Backend API base URL, inlined at build time (`npm run build`). |

Example:

```bash
# Backend on port 8080, accepting requests from a deployed frontend
PORT=8080 CORS_ORIGIN=https://kubeview.example.com go run .

# Frontend built against a deployed backend
NEXT_PUBLIC_API_BASE=https://api.kubeview.example.com/api npm run build
```

## Deploying

### Docker Compose (local)

```bash
docker compose up --build
```

Builds both images and starts the stack against your local cluster: the backend runs on the host network (so it can reach kind/minikube API servers bound to `127.0.0.1`) with `~/.kube/config` mounted read-only, and the dashboard is served at http://localhost:5500.

Notes:
- **Linux, or Docker Desktop with host networking enabled** (Settings → Resources → Network) — host networking is required to reach a local cluster's `127.0.0.1` API server.
- The container runs as UID 1000 by default. If your host UID differs, run `UID=$(id -u) GID=$(id -g) docker compose up --build` so the mounted kubeconfig stays readable.
- Point at a specific kubeconfig with `KUBECONFIG_HOST=/path/to/config` (a single file, not a colon-separated list).

### In-cluster (Kubernetes manifests)

```bash
# Build images and make them available to the cluster, e.g. with kind:
docker build -t kubeview-backend:latest kubeview-backend/
docker build -t kubeview-frontend:latest kubeview-frontend/
kind load docker-image kubeview-backend:latest kubeview-frontend:latest

kubectl apply -k deploy/kubernetes/
kubectl -n kubeview port-forward svc/kubeview-frontend 5500:5500 &
kubectl -n kubeview port-forward svc/kubeview-backend 5501:5501
```

The manifests create a `kubeview` namespace, a `ServiceAccount`, and a `ClusterRole`/`ClusterRoleBinding` granting **read-only** (`get`, `list`, `watch`) access to the resources KubeView surfaces — no write verbs. A `NetworkPolicy` restricts backend ingress to the frontend pod.

> **Security:** the backend API is **unauthenticated** — it serves read-only cluster data (including pod logs, which can contain secrets) under a single service-account identity. The bundled `NetworkPolicy` limits in-cluster access to the frontend, but do not expose the backend Service directly via Ingress/LoadBalancer without putting authentication in front of it.

**Images:** the manifests reference `:latest` with `imagePullPolicy: IfNotPresent` for the `kind load` flow above. To deploy from a registry, push tagged images and update the `image:` fields in `backend.yaml`/`frontend.yaml` (prefer an immutable tag over `:latest`, since `IfNotPresent` will not re-pull a moved `:latest`).

**In-cluster auth:** when no kubeconfig is present (`KUBECONFIG` unset and no `~/.kube/config`), the backend automatically uses the pod's mounted service-account token.

**Frontend API URL:** `NEXT_PUBLIC_API_BASE` is baked into the frontend image at build time and must be the backend URL reachable from the *browser* (for the port-forward flow above, the default `http://localhost:5501/api` works). Rebuild the frontend image with a different build arg to point elsewhere, and set the backend's `CORS_ORIGIN` to the origin the dashboard is served from.

## API reference

The backend exposes the following endpoints. All responses are JSON.

| Method | Path | Description |
| --- | --- | --- |
| GET | `/api/health` | Health check |
| GET | `/api/cluster` | Cluster version, platform, node count, current context |
| GET | `/api/namespaces` | All namespaces |
| GET | `/api/pods?namespace=<ns>` | Pods (optionally filtered by namespace) |
| GET | `/api/pods/:namespace/:name` | Single pod detail |
| GET | `/api/pods/:namespace/:name/logs?container=<c>&tailLines=<n>` | Pod logs (defaults to last 100 lines) |
| GET | `/api/deployments?namespace=<ns>` | Deployments |
| GET | `/api/services?namespace=<ns>` | Services |
| GET | `/api/nodes` | Cluster nodes |
| GET | `/api/events?namespace=<ns>` | Recent cluster events |
| GET | `/api/history/range` | Flight-recorder bounds: whether history is enabled, and the recorded window |
| GET | `/api/history/state?at=<t>` | Cluster state as of a past moment (RFC3339 or unix ms) |
| GET | `/api/history/diff?from=<t1>&to=<t2>` | What changed between two moments, plus the events that fired in between |

## Screenshots

| | |
| --- | --- |
| **Namespaces** ![Namespaces](screenshots/02-namespaces.png) | **Pods** ![Pods](screenshots/03-pods.png) |
| **Pod detail** ![Pod detail](screenshots/04-pod-detail.png) | **Pod logs** ![Pod logs](screenshots/05-pod-logs.png) |
| **Deployments** ![Deployments](screenshots/05-deployments.png) | **Services** ![Services](screenshots/06-services.png) |
| **Nodes** ![Nodes](screenshots/07-nodes.png) | |

## Tech stack

**Backend:** Go 1.26, standard-library `net/http` (`http.ServeMux`), [client-go](https://github.com/kubernetes/client-go) (`k8s.io/client-go`, `k8s.io/api`, `k8s.io/apimachinery`).

**Frontend:** Next.js 16 (App Router), React 19, TypeScript 5, Tailwind CSS v4, ESLint 9.

## Project structure

```
kubeview/
├── kubeview-backend/        # Go API (port 5501)
│   ├── main.go              # Server bootstrap, timeouts, graceful shutdown
│   ├── kube.go              # kubeconfig loading + client-go wrappers
│   ├── handlers.go          # HTTP handlers, router, CORS, error helpers
│   ├── transformers.go      # Reshape K8s objects into frontend JSON
│   ├── history_store.go     # Flight recorder: embedded bbolt store (delta versions, retention pruning)
│   ├── history_recorder.go  # Flight recorder: per-context informers feeding the store
│   ├── history_handlers.go  # /api/history/* endpoints (range, state-at, diff)
│   ├── go.mod
│   └── go.sum
├── kubeview-frontend/       # Next.js dashboard (port 5500)
│   ├── src/
│   │   ├── app/             # App Router pages
│   │   ├── components/      # Sidebar, filters, badges, ...
│   │   └── lib/             # API client + polling hook
│   └── package.json
└── screenshots/             # Images used in this README
```

## Troubleshooting

- **`UnauthorizedError` or `ECONNREFUSED` when starting the backend** — your kubeconfig isn't pointing at a reachable cluster. Run `kubectl get nodes` first; if that fails, the backend will too.
- **The dashboard shows `Failed to fetch`** — make sure the backend is running on port `5501` and that nothing else is using that port.
- **Empty tables** — you may have an empty cluster. Try `kubectl run nginx --image=nginx` to create a pod, then refresh.
