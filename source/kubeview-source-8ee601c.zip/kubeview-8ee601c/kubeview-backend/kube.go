package main

import (
	"context"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"slices"

	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/discovery"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
	"k8s.io/client-go/util/homedir"
)

// emptyKubePath is the sentinel for an unset kubeconfig path or home directory.
const emptyKubePath = ""

// Client wraps a Kubernetes clientset plus contextual info from the kubeconfig.
type Client struct {
	clientset kubernetes.Interface
	// streamClientset carries no client-side timeout: watch and log-follow
	// responses are open-ended, and http.Client.Timeout severs the whole
	// exchange including the body read. Disconnects still end streams via
	// request-context cancellation.
	streamClientset kubernetes.Interface
	discovery       discovery.DiscoveryInterface
	context         string
	cluster         string
}

// Node response shapes. JSON tags must match what the frontend expects in
// kubeview-frontend/src/lib/api.ts.

type NodeCondition struct {
	Type    string `json:"type"`
	Status  string `json:"status"`
	Reason  string `json:"reason,omitempty"`
	Message string `json:"message,omitempty"`
}

type NodeAddress struct {
	Type    string `json:"type"`
	Address string `json:"address"`
}

type NodeInfo struct {
	Name             string            `json:"name"`
	Status           string            `json:"status"`
	Roles            []string          `json:"roles"`
	Version          string            `json:"version"`
	OS               string            `json:"os"`
	Arch             string            `json:"arch"`
	ContainerRuntime string            `json:"containerRuntime"`
	CPU              string            `json:"cpu"`
	Memory           string            `json:"memory"`
	Pods             string            `json:"pods"`
	Labels           map[string]string `json:"labels"`
	Conditions       []NodeCondition   `json:"conditions"`
	CreatedAt        string            `json:"createdAt"`
	Age              string            `json:"age"`
	Addresses        []NodeAddress     `json:"addresses"`
}

// kubeContext bundles the current context and cluster names so
// loadInClusterConfig returns a single distinct type instead of two
// same-typed string results.
type kubeContext struct {
	contextName string
	clusterName string
}

// inClusterName labels both the context and cluster when running off the
// pod's service account, where kubeconfig context names don't exist.
const inClusterName = "in-cluster"

// fileMissing reports whether the path definitely does not exist. A stat
// error that is not "not exist" (e.g. a permission problem on a parent
// directory) returns false so the caller surfaces the real error instead of
// masking it as an in-cluster fallback.
func fileMissing(path string) bool {
	if path == emptyKubePath {
		return true
	}

	_, err := os.Stat(path)

	return errors.Is(err, fs.ErrNotExist)
}

// loadInClusterConfig builds client configuration from the pod's mounted
// service-account token, for deployments running inside the cluster.
func loadInClusterConfig() (*rest.Config, kubeContext, error) {
	var emptyCtx kubeContext

	config, err := rest.InClusterConfig()
	if err != nil {
		return nil, emptyCtx, fmt.Errorf(
			"no kubeconfig found and in-cluster config unavailable: %w", err,
		)
	}

	return config, kubeContext{
		contextName: inClusterName,
		clusterName: inClusterName,
	}, nil
}

// resolveKubeconfigPaths determines the kubeconfig precedence paths, or signals
// that the in-cluster service account should be used instead. An explicitly
// configured KUBECONFIG is honored as-is (a colon-separated list is split and
// merged, matching kubectl). Without it, the implicit ~/.kube/config default is
// used only if present; otherwise useInCluster is true so the caller falls back
// to the pod service account.
func resolveKubeconfigPaths() ([]string, bool) {
	explicit := os.Getenv("KUBECONFIG")
	if explicit != emptyKubePath {
		return filepath.SplitList(explicit), false
	}

	home := homedir.HomeDir()
	if home == emptyKubePath {
		return nil, true
	}

	defaultPath := filepath.Join(home, ".kube", "config")
	if fileMissing(defaultPath) {
		return nil, true
	}

	return []string{defaultPath}, false
}

// loadingRulesFor builds client-config loading rules with the given precedence.
func loadingRulesFor(paths []string) *clientcmd.ClientConfigLoadingRules {
	rules := new(clientcmd.ClientConfigLoadingRules)
	rules.Precedence = paths

	return rules
}

// clusterNameFor resolves the cluster bound to the current context, defaulting
// to "unknown" when it cannot be determined.
func clusterNameFor(raw clientcmdapi.Config, currentContext string) string {
	ctx, ok := raw.Contexts[currentContext]
	if ok && ctx.Cluster != emptyKubePath {
		return ctx.Cluster
	}

	return "unknown"
}

// listOptions returns a zero-value metav1.ListOptions. Built via a var
// declaration (not a composite literal) so the full option set stays at its
// documented defaults without enumerating every field.
func listOptions() metav1.ListOptions {
	var opts metav1.ListOptions

	return opts
}

func getOptions() metav1.GetOptions {
	var opts metav1.GetOptions

	return opts
}

func (c *Client) GetClusterInfo(ctx context.Context) (ClusterInfo, error) {
	var info ClusterInfo

	ver, err := c.discovery.ServerVersion()
	if err != nil {
		return info, fmt.Errorf("server version: %w", err)
	}

	nodes, err := c.clientset.CoreV1().Nodes().List(ctx, listOptions())
	if err != nil {
		return info, fmt.Errorf("list nodes: %w", err)
	}

	return ClusterInfo{
		Version:     ver.GitVersion,
		Platform:    ver.Platform,
		NodeCount:   len(nodes.Items),
		Context:     c.context,
		ClusterName: c.cluster,
	}, nil
}

func (c *Client) ListNamespaces(
	ctx context.Context,
) ([]corev1.Namespace, error) {
	list, err := c.clientset.CoreV1().Namespaces().List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list namespaces: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListPods(
	ctx context.Context,
	namespace string,
) ([]corev1.Pod, error) {
	list, err := c.clientset.CoreV1().Pods(namespace).List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list pods: %w", err)
	}

	return list.Items, nil
}

func (c *Client) GetPod(
	ctx context.Context,
	namespace, name string,
) (*corev1.Pod, error) {
	pods := c.clientset.CoreV1().Pods(namespace)

	pod, err := pods.Get(ctx, name, getOptions())
	if err != nil {
		return nil, fmt.Errorf("get pod: %w", err)
	}

	return pod, nil
}

func (c *Client) GetPodLogs(
	ctx context.Context,
	namespace, name, container string,
	tailLines int64,
) (string, error) {
	// Multi-container pods reject log requests without an explicit container
	// (the API server answers 400), so fall back to the container kubectl
	// would pick: the default-container annotation when it names a real
	// container, else the first spec container.
	if container == emptyKubePath {
		pod, err := c.GetPod(ctx, namespace, name)
		if err != nil {
			return emptyKubePath, err
		}

		container = defaultLogContainer(pod)
	}

	opts := podLogOptions(tailLines, container)
	req := c.clientset.CoreV1().Pods(namespace).GetLogs(name, opts)

	stream, err := req.Stream(ctx)
	if err != nil {
		return emptyKubePath, fmt.Errorf("open log stream: %w", err)
	}

	defer closeLogStream(stream)

	raw, err := io.ReadAll(stream)
	if err != nil {
		return emptyKubePath, fmt.Errorf("read log stream: %w", err)
	}

	return string(raw), nil
}

func (c *Client) StreamPodLogs(
	ctx context.Context,
	namespace, name, container string,
	tailLines int64,
) (io.ReadCloser, error) {
	if container == emptyKubePath {
		pod, err := c.GetPod(ctx, namespace, name)
		if err != nil {
			return nil, err
		}

		container = defaultLogContainer(pod)
	}

	opts := podLogOptions(tailLines, container)
	opts.Follow = true

	stream, err := c.streamClientset.CoreV1().
		Pods(namespace).
		GetLogs(name, opts).
		Stream(ctx)
	if err != nil {
		return nil, fmt.Errorf("open log stream: %w", err)
	}

	return stream, nil
}

// errUnsupportedResource marks a watch request for a resource kind this API
// does not expose; handlers use it to report a client error instead of an
// upstream failure.
var errUnsupportedResource = errors.New("unsupported watch resource")

//nolint:ireturn // client-go exposes watches only as watch.Interface.
func (c *Client) WatchResource(
	ctx context.Context,
	resource, namespace string,
) (watch.Interface, error) {
	options := listOptions()

	var (
		stream watch.Interface
		err    error
	)

	switch resource {
	case resourcePods:
		stream, err = c.streamClientset.CoreV1().
			Pods(namespace).
			Watch(ctx, options)
	case resourceDeployments:
		stream, err = c.streamClientset.AppsV1().
			Deployments(namespace).
			Watch(ctx, options)
	case resourceServices:
		stream, err = c.streamClientset.CoreV1().
			Services(namespace).
			Watch(ctx, options)
	case resourceNodes:
		stream, err = c.streamClientset.CoreV1().Nodes().Watch(ctx, options)
	case resourceNamespaces:
		stream, err = c.streamClientset.CoreV1().
			Namespaces().
			Watch(ctx, options)
	case resourceEvents:
		stream, err = c.streamClientset.CoreV1().
			Events(namespace).
			Watch(ctx, options)
	default:
		return nil, fmt.Errorf("%w %q", errUnsupportedResource, resource)
	}

	if err != nil {
		return nil, fmt.Errorf("watch %s: %w", resource, err)
	}

	return stream, nil
}

// defaultLogContainer picks the container a log request should target when
// the caller did not name one: the kubectl.kubernetes.io/default-container
// annotation when it names any container in the spec (kubectl resolves the
// annotation against regular, init, and ephemeral containers alike), else
// the first regular spec container.
func defaultLogContainer(pod *corev1.Pod) string {
	if annotated, ok := pod.Annotations[annotationDefaultContainer]; ok {
		if specContainerExists(pod, annotated) {
			return annotated
		}
	}

	if len(pod.Spec.Containers) > zeroCount {
		return pod.Spec.Containers[zeroCount].Name
	}

	return emptyKubePath
}

// specContainerExists reports whether any regular, init, or ephemeral
// container in the pod spec has the given name.
func specContainerExists(pod *corev1.Pod, name string) bool {
	hasName := func(c corev1.Container) bool { return c.Name == name }

	return slices.ContainsFunc(pod.Spec.Containers, hasName) ||
		slices.ContainsFunc(pod.Spec.InitContainers, hasName) ||
		slices.ContainsFunc(
			pod.Spec.EphemeralContainers,
			func(c corev1.EphemeralContainer) bool { return c.Name == name },
		)
}

func closeLogStream(stream io.Closer) {
	closeErr := stream.Close()
	if closeErr != nil {
		log.Printf("close log stream: %v", closeErr)
	}
}

// podLogOptions builds the log request options, setting only the fields we
// care about and leaving the rest at their zero defaults.
func podLogOptions(tailLines int64, container string) *corev1.PodLogOptions {
	opts := new(corev1.PodLogOptions)
	opts.TailLines = &tailLines

	if container != "" {
		opts.Container = container
	}

	return opts
}

func (c *Client) ListDeployments(
	ctx context.Context,
	namespace string,
) ([]appsv1.Deployment, error) {
	deployments := c.clientset.AppsV1().Deployments(namespace)

	list, err := deployments.List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list deployments: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListServices(
	ctx context.Context,
	namespace string,
) ([]corev1.Service, error) {
	services := c.clientset.CoreV1().Services(namespace)

	list, err := services.List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list services: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListNodes(ctx context.Context) ([]corev1.Node, error) {
	list, err := c.clientset.CoreV1().Nodes().List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list nodes: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListEvents(
	ctx context.Context,
	namespace string,
) ([]corev1.Event, error) {
	list, err := c.clientset.CoreV1().Events(namespace).List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list events: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListConfigMaps(
	ctx context.Context,
	namespace string,
) ([]corev1.ConfigMap, error) {
	configMaps := c.clientset.CoreV1().ConfigMaps(namespace)

	list, err := configMaps.List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list configmaps: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListSecrets(
	ctx context.Context,
	namespace string,
) ([]corev1.Secret, error) {
	secrets := c.clientset.CoreV1().Secrets(namespace)

	list, err := secrets.List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list secrets: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListIngresses(
	ctx context.Context,
	namespace string,
) ([]networkingv1.Ingress, error) {
	ingresses := c.clientset.NetworkingV1().Ingresses(namespace)

	list, err := ingresses.List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list ingresses: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListStatefulSets(
	ctx context.Context,
	namespace string,
) ([]appsv1.StatefulSet, error) {
	statefulSets := c.clientset.AppsV1().StatefulSets(namespace)

	list, err := statefulSets.List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list statefulsets: %w", err)
	}

	return list.Items, nil
}

func (c *Client) ListDaemonSets(
	ctx context.Context,
	namespace string,
) ([]appsv1.DaemonSet, error) {
	daemonSets := c.clientset.AppsV1().DaemonSets(namespace)

	list, err := daemonSets.List(ctx, listOptions())
	if err != nil {
		return nil, fmt.Errorf("list daemonsets: %w", err)
	}

	return list.Items, nil
}
