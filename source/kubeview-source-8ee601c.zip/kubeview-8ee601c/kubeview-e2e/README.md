# kubeview-e2e

End-to-end tests that drive the **real** stack with Playwright: a real
Kubernetes cluster (kind), the real Go backend, and the production build of
the Next.js frontend. No mocks.

```
kind cluster (seeded fixtures) → Go backend :5501 → Next.js standalone :5500 → Chromium
```

## Running locally

Prerequisites: a running kind (or other local) cluster set as your current
kubectl context, plus Go and Node installed.

```bash
# 1. Seed the deterministic fixtures the specs assert against.
#    Re-run these two lines before each test session: the events specs assert
#    on pod lifecycle events, which Kubernetes garbage-collects after ~1h.
kubectl delete -f fixtures.yaml --ignore-not-found
kubectl apply -f fixtures.yaml
kubectl -n e2e-demo wait --for=condition=Ready pod/e2e-logger pod/e2e-multi --timeout=120s
kubectl -n e2e-demo rollout status statefulset/e2e-db --timeout=120s
kubectl -n e2e-demo rollout status daemonset/e2e-agent --timeout=120s

# 2. Build the frontend (its API base is inlined at build time and defaults
#    to http://localhost:5501/api).
( cd ../kubeview-frontend && npm ci && npm run build )

# 3. Install test deps and browsers.
npm ci
npx playwright install chromium

# 4. Run. Playwright starts the backend and frontend automatically
#    (see webServer in playwright.config.ts).
npm test
```

The backend is launched with `CORS_ORIGIN=http://localhost:5500` against your
current kubeconfig context. In CI (`.github/workflows/ci.yml`, `e2e` job) a
throwaway kind cluster is created first.

## Fixtures

`fixtures.yaml` seeds namespace `e2e-demo` with stable-named resources:
`e2e-logger` (emits a known log line), `e2e-multi` (two containers, for the
log container picker), deployment `e2e-web`, service `e2e-svc`, configmap
`e2e-config`, secret `e2e-secret`, ingresses `e2e-ing-hostonly` (host-only
rule, no http section — backend nil-panic regression guard) and
`e2e-ing-paths`, statefulset `e2e-db`, and daemonset `e2e-agent`.
